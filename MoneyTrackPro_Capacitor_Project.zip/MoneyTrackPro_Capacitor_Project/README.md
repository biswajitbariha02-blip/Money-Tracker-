# MoneyTrack Pro — Capacitor Android project

This project packages the provided HTML app into an Android WebView using Capacitor.

## Build the APK with GitHub Actions (works from a phone)

1. Extract this ZIP.
2. Create a new GitHub repository and upload the contents of this folder (including the `.github` folder).
3. Open the repository's **Actions** tab and enable Actions if prompted.
4. Select **Build MoneyTrack Pro APK** and tap **Run workflow** (or push to `main`).
5. When the run finishes successfully, open the workflow run and download the artifact named `MoneyTrack-Pro-debug-APK`.
6. Extract the downloaded artifact ZIP to get `app-debug.apk`, then install it on your Android phone. Android may ask you to allow installs from that browser/file manager.

## Important notes

- This creates a **debug APK for testing**, not a Play Store release APK.
- The app stores records in browser localStorage. In an Android WebView, data normally stays on that app installation/device; uninstalling or clearing app data can erase it. Export backups regularly.
- Keep the GitHub repository private if you don't want your source code public.
- App ID is `com.moneytrackpro.app`. Change it before distributing if you need a unique package ID.
- A release APK/AAB should be signed securely before publishing.
